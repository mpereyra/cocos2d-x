
// === Auto-generated postamble setup entry stuff ===

{{GLOBAL_VARS}}

function run(args) {
  initRuntime();
}
Module['run'] = run;

// {{PRE_RUN_ADDITIONS}}

run();

// {{POST_RUN_ADDITIONS}}

