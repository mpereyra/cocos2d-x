
# necessary to work around process pool limitations on windows - the js optimizer will end up trying to import this. see issue 663

import tools.js_optimizer

