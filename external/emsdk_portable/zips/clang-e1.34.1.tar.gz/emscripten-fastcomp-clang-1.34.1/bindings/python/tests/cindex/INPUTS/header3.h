// Not a guarded header!

void f();
